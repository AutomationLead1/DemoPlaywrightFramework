import { test, expect } from "@playwright/test";
import path from "path";
import { uploadMultipleFiles,uploadSingleFile } from "../../utils/playwrightUtility";

const singleFilePath = path.join(__dirname, "../../test-data/sample1.txt");
const secondFilePath = path.join(__dirname, "../../test-data/sample2.txt");
let fileURL="https://testautomationpractice.blogspot.com/"

test("Upload a single file", async ({ page }) => {
    await page.goto(fileURL);

    const singleFileInput = page.locator('input[type="file"]').nth(0);

    await uploadSingleFile(singleFileInput, singleFilePath);



    const multipleFileInput = page.locator('input[type="file"]').nth(1);

    await uploadMultipleFiles(
        multipleFileInput,
        [singleFilePath, secondFilePath]
    );

    await page.getByRole("button", { name: "Upload Multiple Files" }).click();
});