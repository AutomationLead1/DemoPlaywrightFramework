import {Page,expect,Locator} from "@playwright/test"

export async function verifyTitleAndURL(
    page:Page,
    expectedTitle:string | RegExp,
    expectedURL:string |RegExp 
){
    await expect(page).toHaveTitle(expectedTitle);
    await expect(page).toHaveURL(expectedURL);
}



export async function uploadSingleFile(
    fileInput: Locator,
    filePath: string
): Promise<void> {
    await fileInput.setInputFiles(filePath);
}

