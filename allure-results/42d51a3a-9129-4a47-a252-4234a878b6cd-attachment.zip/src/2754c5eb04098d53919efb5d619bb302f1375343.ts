import { test, expect } from "@playwright/test";
import path from "path";
import {uploadSingleFile } from "../../utils/playwrightUtility";

const singleFilePath = path.join(__dirname, "../../test-data/sample1.txt");

test("Upload a single file", async ({ page }) => {
    await page.goto("https://testautomationpractice.blogspot.com/");

    const singleFileInput = page.locator('input[type="file"]').nth(0);

    await uploadSingleFile(singleFileInput, singleFilePath);
});