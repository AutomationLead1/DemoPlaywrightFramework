import {Page,expect} from "@playwright/test"

export async function verifyTitleAndURL(
    page:Page,
    expectedTitle:string | RegExp,
    expectedURL:string |RegExp 
){
    await expect(page).toHaveTitle(expectedTitle);
    await expect(page).toHaveURL(expectedURL);
}